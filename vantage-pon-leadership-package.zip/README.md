# PON leadership typography edition

The published architecture is unchanged. This additive four-page draw.io file contains the complete existing architecture followed by three presentation-sized focus views. All original component IDs, parent relationships, geometry, embedded icons and 26 connector endpoint pairs are preserved on the complete page. Focus pages show existing components and their in-view interfaces; they are not deployment diagrams. Their original ownership remains available in metadata and the complete view.

## Typography and PowerPoint placement

- Main title: BentonSans Lig, 33 pt (44 CSS px).
- Headers: BentonSans, 16 pt (21.3333 CSS px).
- Body and connectors: BentonSans, 14 pt (18.6667 CSS px).
- Focus pages: 1280 × 720 CSS px. Insert a complete focus SVG at **13.333 × 7.5 inches** on a standard 16:9 slide to preserve these point sizes. Do not add another title or shrink the image into a smaller placeholder.
- The complete 3760 × 2115 reference page has the same native typography but cannot be shrunk to one slide and still retain a 14 pt apparent body size. Use the focus pages for presenting and the complete page for detailed navigation.
- Install/select the enterprise BentonSans fonts internally. They are named, not embedded. Local PNG previews use a substitute font and do not verify exact BentonSans text fit.

Focus-page connectors retain original interface labels as `interfaceLabel` metadata; visible labels and complete boundaries remain on the complete architecture. Existing technology icons are retained on the complete page; focus views use uncluttered editable text boxes.

No component, technology, interface, approval status or runtime behavior has been added. No files were pushed to GitHub. No external diagrams.net service was used.
